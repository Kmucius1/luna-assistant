# LUNA Slide 3 Design Specification

## Goal

Create a premium "Wellness & Energy" dashboard that feels alive,
luxurious, and calm.

## Canvas

-   iPhone 16 Pro frame
-   Width: 393 px
-   Background: #090613
-   Safe padding: 24 px

## Background

-   Radial gradients:
    -   #28104A
    -   #120A2E
    -   #090613
-   Tiny stars at 10--20% opacity.
-   Very slow animated nebula.

## Header

Centered logo: - LUNA - SF Pro Display Bold - 36 px - White

Top left: - Moon thumbnail (48 px) - Full Moon • 100% - Current time

Top right: - Signal - Wi-Fi - Battery - Profile avatar

## Pagination

7 dots. Current slide highlighted with glowing purple pill.

------------------------------------------------------------------------

# Card 1: Wellness & Energy

Corner radius: 32 px

Glass style: - Background: rgba(28,17,54,.82) - Blur: 24 px - 1 px
border (#8D5CFF at 18%) - Shadow: 0 20 60 rgba(0,0,0,.35)

Title: WELLNESS & ENERGY Purple icon: Heartbeat / ECG

Subtitle: Your mind, body & spirit today

Left: Large circular energy gauge.

Gauge - 240 px - Glow - Progress ring - Animated sweep every few
seconds.

Center: 78 Good Energy

Small gold sparkle beneath.

Right side metrics (4 stacked cards)

Sleep 🌙 icon 7h 42m Status: Good Green

Hydration 💧 icon

Movement 🔥 icon

Energy Peak 📈 icon

Highlight: Later Today

------------------------------------------------------------------------

# Card 2: Today's Flow

Animated glowing spline chart.

Timeline: 12 AM 4 AM 8 AM 12 PM 4 PM 8 PM 12 AM

Icons: 🌙 Rest ☀️ Focus ⭐ Peak 🌙 Wind Down

Peak bubble floats above graph.

------------------------------------------------------------------------

# Card 3: Daily Journal

Left: Quote

"What is one area of my life that is asking for more patience?"

Right: 3D glowing journal illustration

CTA Button

Start Journaling →

Gradient: #6B3DFF to #8D5CFF

Hover glow.

------------------------------------------------------------------------

## Motion

Moon rotates slowly.

Gauge pulses.

Cards float 2 px.

Stars twinkle.

Graph line slowly breathes.

Buttons emit soft glow.

Journal sparkles every 8--10 seconds.

------------------------------------------------------------------------

## Icons

-   Heartbeat
-   Moon
-   Water drop
-   Flame
-   Chart
-   Sparkle
-   Journal
-   Pen

Use Lucide icons.

## Fonts

SF Pro Display SF Pro Text

## Colors

Background #090613

Card #17102E

Purple #8D5CFF

Light Purple #B58CFF

Gold #E6B84A

White #FFFFFF

Secondary #B7AED6

Green #6BE38B

## Spacing

24 px outer padding

32 px card radius

16 px between metric rows

48 px between sections

Perfect vertical rhythm.
