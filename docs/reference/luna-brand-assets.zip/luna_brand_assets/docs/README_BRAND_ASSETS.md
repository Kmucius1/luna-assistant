# LUNA Brand Asset Pack

Drop this folder into the root of the `zoe-assistant` project.

Recommended destination:

```txt
public/brand/
```

## Included

### Logos
- `public/brand/logos/luna-logo.svg` — full LUNA logo with crescent mark
- `public/brand/logos/luna-mark.svg` — square crescent mark
- `public/brand/logos/luna-logo-wordmark.png` — transparent wordmark PNG
- `public/brand/logos/app-icon-1024.png` — app/PWA icon
- Additional app icon sizes: 512, 192, 180, 64

### Backgrounds
- `public/brand/backgrounds/moon-ocean-mobile.png` — mobile full-screen moon background
- `public/brand/backgrounds/moon-ocean-tablet.png` — tablet background
- `public/brand/backgrounds/moon-ocean-desktop.png` — desktop background
- `public/brand/backgrounds/hero-moon-card-mobile.png` — mobile hero card background
- `public/brand/backgrounds/hero-moon-card-desktop.png` — desktop hero card background

### Icons
SVG line icons for the dock and cards:
- home
- work
- luna
- astrology
- explore
- bell
- moon
- star
- money
- night
- style
- dictate
- brain dump
- calendar
- plus

### UI Images
- `luna-message-star.png` — LUNA'S MESSAGE card glow
- `crescent-preview.png` — astrology preview crescent
- `night-cloud.png` — night preview visual
- `style-preview-soft-power.png` — style preview thumbnail

### References
The `/references` folder contains the latest generated UI reference images for Claude to match.

## Claude Implementation Notes

Use the dock labels exactly:

```txt
Home · Work · LUNA · Astrology · Explore
```

Do not use two docks. Do not add Atelier to the dock. Atelier lives inside Explore and can be linked from Style Preview.

Use these imports/paths in Next.js:

```tsx
<img src="/brand/logos/luna-logo.svg" alt="LUNA" />
<img src="/brand/backgrounds/hero-moon-card-mobile.png" alt="" />
<img src="/brand/ui/luna-message-star.png" alt="" />
```

Suggested Tailwind background:

```tsx
<div className="bg-[#050413] text-white">
```

Suggested glass card:

```tsx
className="rounded-[28px] border border-white/10 bg-white/[0.045] backdrop-blur-xl shadow-[inset_0_1px_0_rgba(255,255,255,0.06)]"
```

## Important

These are branding/UI assets only. They do not include secrets, API keys, Plaid tokens, Gmail tokens, or any env files.
